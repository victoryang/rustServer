#ifndef _ERRLOG_H_
#define _ERRLOG_H_

#include "error.h"
#include <share/errinfo.h>

#define MCSERVER_TR(x)	x

#endif
